'use strict';

(function() {
	angular
		.module('app')
		.controller("SignInCtrl", SignInCtrl); // creates a controller named "SignInCtrl"

	SignInCtrl.$inject = ["$scope"];

	function SignInCtrl($scope) {
		
	}
})();
