// degree-programs/degree-programs.service.js

'use strict';

(function(){
	angular
		.module("app")
		.factory("DegreeProgramsService", DegreeProgramsService);

	DegreeProgramsService.$inject = ["$http", "$q"];

	function DegreeProgramsService($http, $q) {
		var url = "http://localhost:5000";
		var service = {};
		service.GetAll = GetAll;
		service.AddDegreeProgram = AddDegreeProgram;
		return service;

		function GetAll() {
			var deferred = $q.defer();

			$http.get(url + "/degree-programs")
			.success(function(data) {
				deferred.resolve(data);
			})
			.error(function (data) {
				deferred.reject("Error: Cannot Retrieve Degree Programs");
			});
			return deferred.promise;
		}

		function AddDegreeProgram(newDegreeProgram) {
			var deferred = $q.defer();

			$http.post(url + "/degree-programs", newDegreeProgram)
			.success(function(data) {
				deferred.resolve(data);
			})
			.error(function(data) {
				deferred.reject("Error: Cannot Add Degree Program");
			});
		
			return deferred.promise;
		}

		function DeleteDegreeProgram(delDegreeProgram) {
			var deferred = $q.defer();

			$http.delete(url + "/degree-programs" + id, delDegreeProgram)
			.success(function(data) {
                alert("Degree Program Deleted Successfully!!!");
				deferred.resolve(data);
			})
			.error(function (error) {
                alert("Unable to delete a degree program!");
                deferred.reject("Error: Cannot Delete Degree Program");
            });
		
			return deferred.promise;
		}

		function UpdateDegreeProgram(upDegreeProgram) {
			var deferred = $q.defer();

			$http.put(url + "/degree-programs", upDegreeProgram)
			.success(function(data) {
				deferred.resolve(data);
			})
			.error(function(data) {
				deferred.reject("Error: Cannot Update Degree Program");
			});
		
			return deferred.promise;
		}

		function RetrieveDegreeProgram(retDegreeProgram) {
			var deferred = $q.defer();

			$http.post(url + "/degree-programs", retDegreeProgram)
			.success(function(data) {
				deferred.resolve(data);
			})
			.error(function(data) {
				deferred.reject("Error: Cannot retrieve Degree Program");
			});
		
			return deferred.promise;
		}

	}
})();


