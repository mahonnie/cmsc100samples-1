// degree-programs/degree-programs.controller.js

'use strict';

(function(){
	angular
		.module("app")
		.controller("DegreeProgramsCtrl", DegreeProgramsCtrl);

	DegreeProgramsCtrl.$inject = ["$scope", "DegreeProgramsService"];

	function DegreeProgramsCtrl($scope, DegreeProgramsService) {
		$scope.degreePrograms=[];

		DegreeProgramsService.GetAll()
			.then(function(data) {
				$scope.degreePrograms = data;
			});

		$scope.AddDegreeProgram = function(){
			DegreeProgramsService.AddDegreeProgram($scope.newDegreeProgram)
				.then(function(data) {
					$scope.newDegreeProgram.code = "";
					$scope.newDegreeProgram.name = "";
					$scope.degreePrograms.push(data);
				});
		}
		
		$scope.DeleteDegreeProgram = function () {
                //Defining $http service for deleting a person
            DegreeProgramsService.DeleteDegreeProgram($scope.delDegreeProgram)
				.then(function(data) {
					$scope.delDegreeProgram.id = "";
					$scope.degreePrograms.data.splice(id, 1);
				});   
        }

        $scope.UpdateDegreeProgram = function(){
			DegreeProgramsService.UpdateDegreeProgram($scope.upDegreeProgram)
				.then(function(data) {
					$scope.upDegreeProgram.code = "";
					$scope.upDegreeProgram.name = "";
					$scope.degreePrograms.push(data);
				});
		}

		$scope.RetrieveDegreeProgram = function(){
			DegreeProgramsService.UpdateDegreeProgram($scope.upDegreeProgram)
				.then(function(data) {
					$scope.retDegreeProgram.code = "";
					$scope.retDegreeProgram.name = "";
					$scope.degreePrograms.push(data);
				});
		}
	}
})();



